// WARNING
//
// This file has been generated automatically by Xamarin Studio to store outlets and
// actions made in the UI designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using MonoMac.Foundation;
using System.CodeDom.Compiler;

namespace BSvsMZP
{
	[Register ("MainWindowController")]
	partial class MainWindowController
	{
		[Outlet]
		MonoMac.AppKit.NSButton excuseAddressButton { get; set; }

		[Outlet]
		MonoMac.AppKit.NSButton excuseListenButton { get; set; }

		[Outlet]
		MonoMac.AppKit.NSTextField excuseListenPortlbl { get; set; }

		[Outlet]
		MonoMac.AppKit.NSTextField excuseMessagesInQueuelbl { get; set; }

		[Outlet]
		MonoMac.AppKit.NSTextField excuseMessagesMovedlbl { get; set; }

		[Outlet]
		MonoMac.AppKit.NSButton excusePortButton { get; set; }

		[Outlet]
		MonoMac.AppKit.NSTextField excuseRemoteAddress { get; set; }

		[Outlet]
		MonoMac.AppKit.NSTextField excuseRemotePort { get; set; }

		[Outlet]
		MonoMac.AppKit.NSButton excuseSendMessageButton { get; set; }

		[Outlet]
		MonoMac.AppKit.NSButton studentListenButton { get; set; }

		[Outlet]
		MonoMac.AppKit.NSTextField studentListenPortlbl { get; set; }

		[Outlet]
		MonoMac.AppKit.NSComboBox studentMessageBox { get; set; }

		[Outlet]
		MonoMac.AppKit.NSTextField studentMessagesInQueuelbl { get; set; }

		[Outlet]
		MonoMac.AppKit.NSTextField studentMessagesMovedlbl { get; set; }

		[Outlet]
		MonoMac.AppKit.NSTextField studentRemoteAddress { get; set; }

		[Outlet]
		MonoMac.AppKit.NSButton studentRemoteAddressButton { get; set; }

		[Outlet]
		MonoMac.AppKit.NSTextField studentRemotePort { get; set; }

		[Outlet]
		MonoMac.AppKit.NSButton studentRemotePortButton { get; set; }

		[Outlet]
		MonoMac.AppKit.NSButton studentSendMessageButton { get; set; }

		[Outlet]
		MonoMac.AppKit.NSButton whineListenButton { get; set; }

		[Outlet]
		MonoMac.AppKit.NSTextField whineListeningPortlbl { get; set; }

		[Outlet]
		MonoMac.AppKit.NSTextField whineMessagesInQueuelbl { get; set; }

		[Outlet]
		MonoMac.AppKit.NSTextField whineMessagesMovedlbl { get; set; }

		[Outlet]
		MonoMac.AppKit.NSTextField whineRemoteAddress { get; set; }

		[Outlet]
		MonoMac.AppKit.NSButton whineRemoteAddressButton { get; set; }

		[Outlet]
		MonoMac.AppKit.NSTextField whineRemotePort { get; set; }

		[Outlet]
		MonoMac.AppKit.NSButton whineRemotePortButton { get; set; }

		[Outlet]
		MonoMac.AppKit.NSButton whineSendMessageButton { get; set; }
		
		void ReleaseDesignerOutlets ()
		{
			if (excuseAddressButton != null) {
				excuseAddressButton.Dispose ();
				excuseAddressButton = null;
			}

			if (excuseListenButton != null) {
				excuseListenButton.Dispose ();
				excuseListenButton = null;
			}

			if (excuseListenPortlbl != null) {
				excuseListenPortlbl.Dispose ();
				excuseListenPortlbl = null;
			}

			if (excuseMessagesInQueuelbl != null) {
				excuseMessagesInQueuelbl.Dispose ();
				excuseMessagesInQueuelbl = null;
			}

			if (excuseMessagesMovedlbl != null) {
				excuseMessagesMovedlbl.Dispose ();
				excuseMessagesMovedlbl = null;
			}

			if (excusePortButton != null) {
				excusePortButton.Dispose ();
				excusePortButton = null;
			}

			if (excuseRemoteAddress != null) {
				excuseRemoteAddress.Dispose ();
				excuseRemoteAddress = null;
			}

			if (excuseRemotePort != null) {
				excuseRemotePort.Dispose ();
				excuseRemotePort = null;
			}

			if (excuseSendMessageButton != null) {
				excuseSendMessageButton.Dispose ();
				excuseSendMessageButton = null;
			}

			if (studentListenButton != null) {
				studentListenButton.Dispose ();
				studentListenButton = null;
			}

			if (studentListenPortlbl != null) {
				studentListenPortlbl.Dispose ();
				studentListenPortlbl = null;
			}

			if (studentMessageBox != null) {
				studentMessageBox.Dispose ();
				studentMessageBox = null;
			}

			if (studentMessagesInQueuelbl != null) {
				studentMessagesInQueuelbl.Dispose ();
				studentMessagesInQueuelbl = null;
			}

			if (studentMessagesMovedlbl != null) {
				studentMessagesMovedlbl.Dispose ();
				studentMessagesMovedlbl = null;
			}

			if (studentRemoteAddress != null) {
				studentRemoteAddress.Dispose ();
				studentRemoteAddress = null;
			}

			if (studentRemoteAddressButton != null) {
				studentRemoteAddressButton.Dispose ();
				studentRemoteAddressButton = null;
			}

			if (studentRemotePort != null) {
				studentRemotePort.Dispose ();
				studentRemotePort = null;
			}

			if (studentRemotePortButton != null) {
				studentRemotePortButton.Dispose ();
				studentRemotePortButton = null;
			}

			if (studentSendMessageButton != null) {
				studentSendMessageButton.Dispose ();
				studentSendMessageButton = null;
			}

			if (whineRemoteAddress != null) {
				whineRemoteAddress.Dispose ();
				whineRemoteAddress = null;
			}

			if (whineRemoteAddressButton != null) {
				whineRemoteAddressButton.Dispose ();
				whineRemoteAddressButton = null;
			}

			if (whineRemotePort != null) {
				whineRemotePort.Dispose ();
				whineRemotePort = null;
			}

			if (whineRemotePortButton != null) {
				whineRemotePortButton.Dispose ();
				whineRemotePortButton = null;
			}

			if (whineListeningPortlbl != null) {
				whineListeningPortlbl.Dispose ();
				whineListeningPortlbl = null;
			}

			if (whineListenButton != null) {
				whineListenButton.Dispose ();
				whineListenButton = null;
			}

			if (whineMessagesMovedlbl != null) {
				whineMessagesMovedlbl.Dispose ();
				whineMessagesMovedlbl = null;
			}

			if (whineMessagesInQueuelbl != null) {
				whineMessagesInQueuelbl.Dispose ();
				whineMessagesInQueuelbl = null;
			}

			if (whineSendMessageButton != null) {
				whineSendMessageButton.Dispose ();
				whineSendMessageButton = null;
			}
		}
	}

	[Register ("MainWindow")]
	partial class MainWindow
	{
		
		void ReleaseDesignerOutlets ()
		{
		}
	}
}
